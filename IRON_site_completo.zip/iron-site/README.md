# IRON — Site institucional + demonstração interativa

Landing page premium e responsiva para apresentar o projeto IRON, acompanhada de uma **demonstração independente** de cinco telas: Início, Treino, Evolução, Amigos e Perfil.

## Como abrir

É um site estático (HTML + CSS + JavaScript). Não precisa de Node, npm, banco de dados, chave de API ou build.

Para testar localmente, na pasta do projeto execute:

```sh
python -m http.server 8000
```

Acesse `http://localhost:8000`. Você também pode fazer deploy da pasta diretamente no Vercel, Netlify, Cloudflare Pages ou outra hospedagem de arquivos estáticos.

**Importante:** use um servidor HTTP local para que os ícones SVG externos funcionem de forma consistente em todos os navegadores. Abrir com duplo clique pode bloquear esses ícones por restrições de `file://`.

## Arquivos

- `index.html` — landing page completa do IRON.
- `styles.css` — identidade visual, tipografia, animações e responsividade da landing page.
- `app.js` — menu móvel, tabs e animações de entrada.
- `demo.html` — app de demonstração com cinco telas.
- `demo.css` — estilos da demo desktop e mobile.
- `demo.js` — registro de séries, cargas, repetições, descanso, estatísticas e histórico local.
- `assets/icons.svg` — biblioteca de ícones vetoriais.
- `assets/favicon.svg` — ícone do projeto.

## Funcionalidade da demo

- Navegação entre 5 telas pelo menu desktop/mobile.
- Ficha A com 4 exercícios; edição de carga e repetições, marcar/desmarcar séries, adicionar e remover séries.
- Descanso de 1min30 com iniciar, pausar e reiniciar.
- Finalização do treino com resumo e cópia para a área de transferência.
- Atualização dos gráficos, totais e histórico após o treino.
- Atividades e medalhas fictícias, botões de apoio e perfil privado/público simulado.
- Persistência das alterações via `localStorage` no próprio navegador; botão para reiniciar tudo.

## Observações de produto

O site **não** é uma interface para contas reais do IRON, não usa Supabase e não captura cadastros. Todos os exemplos, nomes e volumes são fictícios, e o material identifica que o app está em desenvolvimento e beta fechado.

O IRON Coach é descrito de maneira fiel como **análise algorítmica**, sem alegar que usa IA generativa hoje. Não há promessas de disponibilidade pública, assinaturas, ranking global, dados clínicos ou recursos ainda não publicados.

Antes de publicar, troque textos e visuais demonstrativos por screenshots reais aprovadas, revise as declarações de funcionalidades e adicione URLs oficiais (Google Play, domínio, suporte e políticas) quando estiverem disponíveis. Não incluí links, páginas legais ou formulários com back-end inventados.

O site usa fontes do Google Fonts (Manrope / DM Sans) com fallback sem fontes externas. Ícones, diagramas, dashboards e cards são criados com HTML/CSS/SVG locais.

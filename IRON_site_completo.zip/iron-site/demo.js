(() => {
  'use strict';
  const STORAGE_KEY = 'iron-concept-demo-v1';
  const EXERCISES = [
    { id: 'supino', name: 'Supino inclinado', detail: 'Halteres · Peito', muscle: 'PEITO', sets: [{kg:20,reps:10,done:false},{kg:22.5,reps:8,done:false},{kg:22.5,reps:8,done:false}] },
    { id: 'puxada', name: 'Puxada alta', detail: 'Polia · Costas', muscle: 'COSTAS', sets: [{kg:40,reps:12,done:false},{kg:44,reps:10,done:false},{kg:44,reps:10,done:false}] },
    { id: 'lateral', name: 'Elevação lateral', detail: 'Halteres · Ombros', muscle: 'OMBROS', sets: [{kg:8,reps:12,done:false},{kg:8,reps:12,done:false}] },
    { id: 'rosca', name: 'Rosca direta', detail: 'Barra · Bíceps', muscle: 'BRAÇOS', sets: [{kg:20,reps:10,done:false},{kg:20,reps:10,done:false}] }
  ];
  function daysAgo(days) { const d = new Date(); d.setDate(d.getDate() - days); return d.toISOString(); }
  function freshState() {
    return {
      exercises: structuredClone(EXERCISES),
      sessions: [
        {id:'sample-1',date:daysAgo(13),name:'Ficha A',volume:820,sets:8,exercises:4,sample:true},
        {id:'sample-2',date:daysAgo(8),name:'Ficha B',volume:1060,sets:9,exercises:5,sample:true},
        {id:'sample-3',date:daysAgo(3),name:'Ficha C',volume:940,sets:8,exercises:4,sample:true}
      ],
      privateProfile:true
    };
  }
  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return freshState();
      const parsed = JSON.parse(raw);
      if (!parsed || !Array.isArray(parsed.sessions) || !Array.isArray(parsed.exercises) || parsed.exercises.length !== EXERCISES.length || typeof parsed.privateProfile !== 'boolean') return freshState();
      if (parsed.sessions.length > 100 || parsed.exercises.some(x => !Array.isArray(x.sets) || x.sets.length > 20)) return freshState();
      return parsed;
    } catch { return freshState(); }
  }
  let state = loadState();
  const save = () => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch { /* Continua funcional mesmo sem armazenamento disponível. */ } };
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const icon = (name, extra='') => `<svg class="icon ${extra}" aria-hidden="true"><use href="assets/icons.svg#${name}"/></svg>`;
  const formatNumber = n => Number(n || 0).toLocaleString('pt-BR', {maximumFractionDigits:1});
  const clamp = (n, min, max) => Math.max(min, Math.min(max, Number.isFinite(n) ? n : min));
  const pages = ['inicio','treino','evolucao','amigos','perfil'];
  const titles = {inicio:'Visão geral',treino:'Meu treino',evolucao:'Evolução',amigos:'Amigos',perfil:'Perfil'};
  let toastTimer;
  function toast(msg) {
    const target = $('#toast'); if (!target) return;
    target.textContent = msg;
    target.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => target.classList.remove('show'), 3300);
  }
  function go(screen, updateHash=true) {
    if (!pages.includes(screen)) screen = 'inicio';
    $$('.demo-page').forEach(p => p.classList.toggle('active', p.id === `screen-${screen}`));
    $$('[data-go]').forEach(b => {
      const isCurrent = b.dataset.go === screen;
      b.classList.toggle('active', isCurrent);
      if (isCurrent) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current');
    });
    $('#current-section').textContent = titles[screen];
    if (updateHash && location.hash !== `#${screen}`) history.replaceState(null,'',`#${screen}`);
    if (screen === 'treino') renderWorkout();
    if (screen === 'evolucao') renderProgress();
    if (screen === 'inicio') renderHome();
    if (screen === 'perfil') renderProfile();
    window.scrollTo({top:0,behavior:'instant'});
  }
  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-go]');
    if (!btn) return;
    e.preventDefault();
    go(btn.dataset.go);
  });
  window.addEventListener('hashchange', () => go(location.hash.slice(1),false));

  function totals() {
    return {
      sessions:state.sessions.length,
      volume:state.sessions.reduce((sum,s) => sum + Number(s.volume||0),0),
      sets:state.sessions.reduce((sum,s) => sum + Number(s.sets||0),0)
    };
  }
  function sessionCalc() {
    let complete=0, total=0, volume=0, started=0;
    for (const exercise of state.exercises) {
      let any=false;
      for (const s of exercise.sets) {
        total++;
        if(s.done) { complete++; any=true; volume+=Number(s.kg||0)*Number(s.reps||0); }
      }
      if(any) started++;
    }
    return {complete,total,volume,started};
  }

  function renderWorkout() {
    const container = $('#exercises');
    if (!container) return;
    container.innerHTML = state.exercises.map((ex,i) => {
      const rows = ex.sets.map((s,j) => `<div class="set-line ${s.done?'done':''}" data-exercise="${i}" data-set="${j}">
          <span class="set-index">${String(j+1).padStart(2,'0')}</span>
          <input class="set-input" type="number" min="0" max="500" step="0.5" inputmode="decimal" aria-label="Carga da série ${j+1} de ${ex.name} em quilos" data-field="kg" value="${s.kg}">
          <input class="set-input" type="number" min="0" max="100" step="1" inputmode="numeric" aria-label="Repetições da série ${j+1} de ${ex.name}" data-field="reps" value="${s.reps}">
          <button type="button" class="set-check ${s.done?'checked':''}" data-action="complete" aria-label="${s.done?'Desmarcar':'Concluir'} série ${j+1} de ${ex.name}" aria-pressed="${s.done}">${icon('check','sm')}</button>
          <button type="button" class="remove-set" data-action="remove" aria-label="Remover série ${j+1} de ${ex.name}" ${ex.sets.length <= 1?'disabled':''}>${icon('close','sm')}</button>
        </div>`).join('');
      return `<article class="exercise-card" data-exercise-card="${i}"><div class="exercise-card-header"><div class="exercise-num">${String(i+1).padStart(2,'0')}</div><div><h3>${ex.name}</h3><p>${ex.detail}</p></div><span class="exercise-muscle">${ex.muscle}</span></div><div class="set-table-head"><span>SÉRIE</span><span>KG</span><span>REPS</span><span>OK</span><span></span></div>${rows}<div class="exercise-card-footer"><button class="add-set" data-action="add" data-exercise="${i}">${icon('plus','sm')} Adicionar série</button><button class="rest-shortcut" data-action="rest">${icon('clock','sm')} Descansar 1:30</button></div></article>`;
    }).join('');
    updateLiveStats();
  }
  function updateLiveStats() {
    const c = sessionCalc();
    $('#live-volume').textContent = formatNumber(c.volume);
    $('#live-sets').textContent = `${c.complete} / ${c.total}`;
    $('#live-exercises').textContent = `${c.started} / ${state.exercises.length}`;
    $('#summary-bar').style.width = `${Math.round(c.complete/Math.max(1,c.total)*100)}%`;
  }
  $('#exercises').addEventListener('input', (event) => {
    const input = event.target.closest('.set-input'); if (!input) return;
    const row = input.closest('.set-line');
    const ex = state.exercises[Number(row.dataset.exercise)]; const s = ex?.sets[Number(row.dataset.set)]; if (!s) return;
    s[input.dataset.field] = clamp(Number(input.value),0,input.dataset.field === 'kg' ? 500 : 100);
    save();updateLiveStats();
  });
  $('#exercises').addEventListener('change', (event) => {
    const input = event.target.closest('.set-input'); if (!input) return;
    const max = input.dataset.field === 'kg' ? 500 : 100;
    const value = clamp(Number(input.value),0,max);
    input.value = String(value);
  });
  $('#exercises').addEventListener('click', e => {
    const btn = e.target.closest('button[data-action]'); if (!btn) return;
    const action = btn.dataset.action;
    if (action === 'rest') { resetTimer();startTimer();return; }
    if (action === 'add') {
      const ex=state.exercises[Number(btn.dataset.exercise)];
      if(!ex || ex.sets.length >= 15) {toast('Máximo de 15 séries por exercício nesta demo.');return;}
      const last=ex.sets[ex.sets.length-1];
      ex.sets.push({kg:last.kg,reps:last.reps,done:false});
      save();renderWorkout();return;
    }
    const row=btn.closest('.set-line'); if(!row) return;
    const ex=state.exercises[Number(row.dataset.exercise)];
    const index=Number(row.dataset.set);const set=ex?.sets[index];if (!set) return;
    if (action === 'complete') {
      set.done = !set.done;
      save();renderWorkout();
      toast(set.done ? 'Série concluída. Continue assim!' : 'Série desmarcada.');
    } else if (action === 'remove' && ex.sets.length > 1) {
      ex.sets.splice(index,1);save();renderWorkout();
    }
  });

  const chart = (data,opts={}) => {
    if (!data.length) return '';
    const w=760,h=236,padX=26,padTop=20,padBottom=36;
    const volumes = data.map(s=>Math.max(0,Number(s.volume)||0));
    const high=Math.max(...volumes,100)*1.13;
    const calcX=i=>padX + i * (w-padX*2)/Math.max(1,data.length-1);
    const calcY=v=>h-padBottom - (v/high)*(h-padTop-padBottom);
    const points=data.map((s,i)=>`${calcX(i).toFixed(1)},${calcY(volumes[i]).toFixed(1)}`).join(' ');
    const path=data.map((s,i)=>`${i===0?'M':'L'}${calcX(i).toFixed(1)} ${calcY(volumes[i]).toFixed(1)}`).join(' ');
    const area=`${path} L${calcX(data.length-1).toFixed(1)} ${h-padBottom} L${padX} ${h-padBottom} Z`;
    const lines=[.25,.5,.75,1].map(f=>`<line x1="${padX}" y1="${calcY(high*f)}" x2="${w-padX}" y2="${calcY(high*f)}" stroke="#829da9" stroke-opacity=".16" stroke-dasharray="4 7"/>`).join('');
    const dots=data.map((s,i)=>`<circle cx="${calcX(i)}" cy="${calcY(volumes[i])}" r="${i===data.length-1?5:3}" fill="${s.sample?'#7e9ca7':'#dfedf1'}" stroke="#172127" stroke-width="3"/>`).join('');
    const labels=data.map((s,i)=>`<text x="${calcX(i)}" y="${h-6}" fill="#8199a5" font-size="11" text-anchor="middle">${i+1}</text>`).join('');
    return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" role="img" aria-label="Gráfico de volume por sessão com ${data.length} registros"><defs><linearGradient id="${opts.id||'volume-gradient'}" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#a5d0da" stop-opacity=".20"/><stop offset="100%" stop-color="#a5d0da" stop-opacity="0"/></linearGradient></defs>${lines}<path d="${area}" fill="url(#${opts.id||'volume-gradient'})"/><path d="${path}" fill="none" stroke="#c0e4ea" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>${dots}${labels}</svg>`;
  };
  function renderWeek() {
    const host=$('#demo-week');if(!host) return;
    const today=new Date();const day=(today.getDay()+6)%7;
    const monday=new Date(today.getFullYear(), today.getMonth(),today.getDate()-day);
    const dayNames=['SEG','TER','QUA','QUI','SEX','SÁB','DOM'];
    const days=Array.from({length:7},(_,i)=>{
      const d=new Date(monday);d.setDate(d.getDate()+i);
      const completed=state.sessions.some(s => {const sd=new Date(s.date);return sd.getFullYear()===d.getFullYear()&&sd.getMonth()===d.getMonth()&&sd.getDate()===d.getDate();});
      return `<span class="${completed?'done ':''}${i===day?'today':''}" title="${completed?'Treino registrado':'Sem registro'}"><small>${dayNames[i]}</small>${d.getDate()}</span>`;
    });
    host.innerHTML=days.join('');
  }
  function renderHome(){
    const t=totals();
    $('#home-workouts').textContent=formatNumber(t.sessions);
    $('#home-volume').textContent=formatNumber(t.volume);
    $('#home-sets').textContent=formatNumber(t.sets);
    const entries=state.sessions.slice(-10);
    $('#home-chart').innerHTML=chart(entries,{id:'home-area'});
    $('#coach-message').textContent=state.sessions.some(s=>!s.sample)
      ? 'Você concluiu um treino nesta demonstração. Observe como uma sessão registrada já aparece no seu histórico e em seus indicadores.'
      : 'Seus registros mostram como o histórico pode dar contexto a cada sessão. Termine uma ficha na demo e veja seus números mudarem.';
    renderWeek();
  }
  function renderProgress() {
    const t=totals();
    $('#progress-volume').textContent=formatNumber(t.volume);
    $('#progress-sessions').textContent=formatNumber(t.sessions);
    $('#best-volume').textContent=formatNumber(Math.max(0,...state.sessions.map(s=>Number(s.volume||0))));
    $('#progress-chart').innerHTML=chart(state.sessions.slice(-12),{id:'progress-area'});
    const items=[...state.sessions].reverse().slice(0,8);
    $('#session-history').innerHTML=items.map(s=>`<div class="history-row"><div class="history-icon">${icon('dumbbell','sm')}</div><div class="history-details"><strong>${s.name}</strong><small>${new Date(s.date).toLocaleDateString('pt-BR')} · ${s.sets} séries · ${s.sample?'Exemplo':'Você registrou na demo'}</small></div><span class="history-volume">${formatNumber(s.volume)} kg</span></div>`).join('');
    $('#progress-insight').textContent=state.sessions.some(s=>!s.sample)
      ? 'Seu treino demonstrativo foi incluído no histórico. Compare as sessões ao longo do tempo, mas lembre: volume isolado não mede toda a sua evolução.'
      : 'Treino a treino, números formam um histórico. Acompanhar volume, constância e recordes pode revelar tendências — sem precisar adivinhar.';
  }
  function renderProfile() {
    const t=totals();
    $('#profile-workouts').textContent=formatNumber(t.sessions);
    $('#profile-volume').textContent=formatNumber(t.volume);
    $('#profile-sets').textContent=formatNumber(t.sets);
    $('#private-toggle').checked=state.privateProfile;
    $('#privacy-status').innerHTML=state.privateProfile
      ? `${icon('lock','sm')} Seu perfil de exemplo está privado.`
      : `${icon('users','sm')} Seu perfil de exemplo está público nesta simulação.`;
  }
  $('#private-toggle').addEventListener('change', e=>{
    state.privateProfile=e.target.checked;save();renderProfile();toast(state.privateProfile?'Perfil da demo marcado como privado.':'Perfil da demo marcado como público.');
  });
  $$('.like-button').forEach(b=>b.addEventListener('click',()=>{
    const liked=b.classList.toggle('liked');
    b.setAttribute('aria-pressed',String(liked));
    b.querySelector('span').textContent=liked?'Apoiado':'Apoiar';
  }));

  let seconds=90;let running=false;let interval=null;
  function showTime(){
    $('#timer-display').textContent=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;
    $('#timer-play').innerHTML=`${icon(running?'pause':'play','sm')} ${running?'Pausar':'Iniciar'}`;
  }
  function pauseTimer(){if(interval!==null)clearInterval(interval);interval=null;running=false;showTime();}
  function startTimer(){
    if(running)return;
    if(seconds<=0)seconds=90;
    running=true;showTime();
    interval=setInterval(()=>{seconds--;if(seconds<=0){seconds=0;pauseTimer();toast('Descanso concluído. Próxima série!');}showTime();},1000);
  }
  function resetTimer(){pauseTimer();seconds=90;showTime();}
  $('#timer-play').addEventListener('click',()=>running?pauseTimer():startTimer());
  $('#timer-reset').addEventListener('click',resetTimer);

  const dialog=$('#finish-dialog');
  function finishWorkout(){
    const c=sessionCalc();
    if(!c.complete){toast('Conclua pelo menos uma série para finalizar o treino.');go('treino');return;}
    const totalVolume=Math.round(c.volume*10)/10;
    state.sessions.push({id:`local-${Date.now()}`,date:new Date().toISOString(),name:'Ficha A',volume:totalVolume,sets:c.complete,exercises:c.started,sample:false});
    state.exercises=structuredClone(EXERCISES);
    save();renderWorkout();renderHome();renderProgress();renderProfile();
    $('#finish-volume').textContent=`${formatNumber(totalVolume)} kg`;
    $('#finish-sets').textContent=String(c.complete);
    dialog.showModal();
    pauseTimer();
  }
  $('#finish-workout').addEventListener('click',finishWorkout);
  $('#finish-top').addEventListener('click',finishWorkout);
  $('#modal-close').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});
  $('#view-evolution').addEventListener('click',()=>{dialog.close();go('evolucao');});
  $('#copy-summary').addEventListener('click',async()=>{
    const latest=state.sessions.at(-1);
    if(!latest || latest.sample) return;
    const text=`IRON — Treino concluído!\n${latest.name}\n${latest.sets} séries · ${formatNumber(latest.volume)} kg de volume\nMinha evolução, um treino de cada vez.`;
    try {
      if(navigator.clipboard?.writeText) await navigator.clipboard.writeText(text);
      else {
        const field=document.createElement('textarea');field.value=text;field.style.position='fixed';field.style.opacity='0';document.body.append(field);field.select();
        if(!document.execCommand('copy'))throw new Error('Copy failed');field.remove();
      }
      toast('Resumo copiado!');
    }catch{toast('O navegador não permitiu copiar. Tente de novo em HTTPS.');}
  });
  $('#reset-demo').addEventListener('click',()=>{
    if(!window.confirm('Reiniciar a demonstração? Seus treinos de exemplo registrados neste navegador serão apagados.'))return;
    state=freshState();save();resetTimer();renderWorkout();renderHome();renderProgress();renderProfile();
    $$('.like-button').forEach(b=>{b.classList.remove('liked');b.setAttribute('aria-pressed','false');b.querySelector('span').textContent='Apoiar';});
    go('inicio');toast('Demonstração reiniciada.');
  });

  renderHome();renderProgress();renderWorkout();renderProfile();showTime();
  go(location.hash.slice(1),false);
})();
